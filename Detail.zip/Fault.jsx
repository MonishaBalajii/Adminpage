import React from 'react';
import './App.css';

function App() {
    return (
        <div className="App">
            <header className="header">
                <h1>Placement Portal</h1>
            </header>
            <div className="content">
                <h2>Welcome to the Placement Portal!</h2>
                <p>This is the place where you can find job opportunities and internships.</p>
                <h3>Latest Job Openings</h3>
                <ul>
                    <li>Software Engineer at ABC Tech</li>
                    <li>Marketing Intern at XYZ Company</li>
                </ul>
                <p>For more details, please login to your account.</p>
            </div>
        </div>
    );
}

export default App;
